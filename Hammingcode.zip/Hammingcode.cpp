#include<iostream>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#include<stdio.h>

using namespace std;
class receiver;

class sender
{
public:
    int i,parity_type,message_size,msg[100],parity_bit=0;
    void getdata();
    void parity_bit_count();

    int message[100],p=0,d=1;
    void making_box();

    void encode_parity_bit();

    int j=1,k,count1,count;
    void even_odd_count();

    void codeword_print();

    friend receiver;
};

class receiver
{
public:
    int random,random1,m[100],i;
    void two_random_cal(sender);
    void two_error_codeword_print(sender);

    int newa[100],j=1;
    void two_error_detection(sender);

    int n[100];
    void one_random_cal(sender);
    void one_error_codeword_print(sender);

    int new1[100];
    void one_error_detection(sender);


};


void receiver :: one_error_detection(sender a) /// Error detect + Bit number error
{
    int j=1,count1,count,k;
    while(j<=a.parity_bit)
    {

        count1=0;
        count=pow(2,j-1);
        i=count-1;
        while(i<=a.message_size+a.parity_bit)
        {
            k=1;
            while(k<=count)
            {
                if(n[i+k]==1)
                    count1++;
                k++;
            }
            i=i+count+k-1;
        }

        if(a.parity_type==1)
        {
            if(count1%2==0)
                new1[j]=1;

            else
                new1[j]=0;

        }
        else
        {
            if(count1%2==0)
                new1[j]=0;

            else
                new1[j]=1;

        }

        j++;


    }
    printf("\n\nError: ");
    for(i=a.parity_bit; i>=1; i--)
        cout<<new1[i]<<" ";

    int decimal=0;
    for(i=a.parity_bit; i>0; i--)
        decimal=decimal+pow(2,i-1)*new1[i];

    printf("\n\nDecimal errror: %d",decimal);

    if(n[decimal]==0)
        n[decimal]=1;
    else
        n[decimal]=0;

    printf("\n\nNow true Message is:");

    for (i = 1; i <=a.message_size+a.parity_bit ; i++)
    {
        printf("%d ",n[i]);
    }

}

void receiver :: one_error_codeword_print(sender a) /// 1 bit error message print
{
    printf("\n\n1 bit error codeword:");
    for (i = 1; i <=a.message_size+a.parity_bit ; i++)
    {
        printf("%d ",n[i]);
    }
}

void receiver :: one_random_cal(sender a) ///Creating 1 bit error
{
    int rando = rand()%(a.message_size+a.parity_bit);

    for(i=1; i<=a.message_size+a.parity_bit; i++)
        n[i]=a.message[i];

    if(n[rando]==0)
        n[rando]=1;
    else
        n[rando]=0;

}

void receiver :: two_error_detection(sender a) /// Error detect + Bit number error
{
    int j=1,count1,count,k;
    printf("\n\nError: ");
    while(j<=a.parity_bit)
    {
        count1=0;
        count=pow(2,j-1);
        i=count-1;
        while(i<=a.message_size+a.parity_bit)
        {
            k=1;
            while(k<=count)
            {
                if(m[i+k]==1)
                    count1++;
                k++;
            }
            i=i+count+k-1;
        }

        if(a.parity_type==1)
        {
            if(count1%2==0)
                newa[j]=1;

            else
                newa[j]=0;

        }
        else
        {
            if(count1%2==0)
                newa[j]=0;

            else
                newa[j]=1;

        }
        printf("%d ",newa[j]);  /// Error bit no.
        j++;


    }


}

void receiver :: two_error_codeword_print(sender a) /// 2 bit error message print
{
    printf("\n\n2 bit error codeword: ");
    for (i = 1; i <=a.message_size+a.parity_bit ; i++)
    {
        printf("%d ",m[i]);
    }
}
void receiver :: two_random_cal(sender a) /// Creating 2 bit error ///
{
    for(i=1; i<=a.message_size+a.parity_bit; i++)
        m[i]=a.message[i];
    random = rand()%(a.message_size+a.parity_bit);
    random1 = rand()%(a.message_size+a.parity_bit);
    if(m[random]==0)
        m[random]=1;
    else
        m[random]=0;

    if(m[random1]==0)
        m[random1]=1;
    else
        m[random1]=0;
}

void sender ::codeword_print() /// codeword print
{
    printf("Codeword:");
    for(i=1; i<=message_size+parity_bit; i++)
        printf("%d ",message[i]);
}

void sender :: even_odd_count() /// Binary + count odd / even ///
{
    while(j<=parity_bit)
    {
        count1=0;
        count=pow(2,j-1);
        i=count-1;
        while(i<=message_size+parity_bit)
        {
            k=1;
            while(k<=count)
            {
                if(message[i+k]==1)
                    count1++;
                k++;
            }
            i=i+count+k-1;
        }
        if(parity_type==1)
        {
            if(count1%2==0)
                message[count]=1;

            else
                message[count]=0;
        }
        else
        {
            if(count1%2==0)
                message[count]=0;

            else
                message[count]=1;
        }
        j++;
    }
}

void sender :: encode_parity_bit() ///Data Bits are Encoded with Parity bits(0)
{
    printf(" \nData Bits are Encoded with Parity bits(0): ");
    for (i = 1; i <=message_size+parity_bit ; i++)
    {
        printf("%d ",message[i]);
    }
    printf("\n\n");

}

void sender :: making_box() /// parity bit + data + making box ///
{
    for (i = 1; i <= message_size+parity_bit; i++)
    {
        if (i==pow(2, p))
        {
            message[i] = 0;
            p++;
        }
        else
        {
            message[i] = msg[d];
            d++;
        }
    }

}

void sender :: parity_bit_count() /// Parity bit count ///
{
    while (message_size + parity_bit + 1 > pow (2, parity_bit))
    {
        parity_bit++;
    }

}

void sender :: getdata()  /// Enter message size + massage + parity type ///
{

    printf("Enter message size: ");
    scanf("%d",&message_size);

    printf("\nEnter message's bit one by one:");
    for(i=1; i<=message_size; i++)
        scanf("%d",&msg[i]);

    printf("\nEnter Parity type(0=Even & 1=Odd): ");
    scanf("%d",&parity_type);
}


int main()
{
    sender mahfuz;

    mahfuz.getdata();
    mahfuz.parity_bit_count();
    mahfuz.making_box();
    mahfuz.encode_parity_bit();
    mahfuz.even_odd_count();
    mahfuz.codeword_print();

    receiver mahbub;

    mahbub.two_random_cal(mahfuz);
    mahbub.two_error_codeword_print(mahfuz);
    mahbub.two_error_detection(mahfuz);

    mahbub.one_random_cal(mahfuz);
    mahbub.one_error_codeword_print(mahfuz);
    mahbub.one_error_detection(mahfuz);

    getch();

}
